// The unique ID for the session
var id;
// Set to whatever URL you want your webapp to call
var urlToCall = "https://66278588.eu-gb.apigw.appdomain.cloud/elektra";

function setID(idToSet) {
  id = idToSet;
}

function makeid()
{
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for( var i=0; i < 5; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    var d = new Date();
    var time_string = d.getTime();
    var id = text + time_string;
    return id;
}

function formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0'+minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
}

function startConversation(id) {
  //$.mobile.loading("show");
  var txt = "start";

  var dataToPost = "{\"text\": \"" + txt + "\", \"id\": \"" + id + "\"}";

  // The URI to call when invoking the service facade for the conversation service
  //var toCall = "https://api.eu-de.apiconnect.ibmcloud.com/jkj-org-dev/sb/test-conversation-api/telia";
  var toCall = urlToCall;
  $.ajax({

    url: toCall,
    type: 'POST',
    data: dataToPost,
    Accept : "application/json",
    contentType: "application/json",
    success:function(res){
      var msg = res.message;
      //$.mobile.loading("hide");
      insertChat("me", msg, 0);

    },
    error:function(res){
      //$.mobile.loading("hide");
      alert("I'm afraid something is not working right now. Wait for a while and then give it another try.)");
    }
  });
};

function continueConversation(id) {
  //$.mobile.loading("show");
  var txt = "continue";

  var dataToPost = "{\"text\": \"" + txt + "\", \"id\": \"" + id + "\"}";

  // The URI to call when invoking the service facade for the conversation service
  //var toCall = "https://api.eu-de.apiconnect.ibmcloud.com/jkj-org-dev/sb/test-conversation-api/telia";
  var toCall = urlToCall;
  $.ajax({

    url: toCall,
    type: 'POST',
    data: dataToPost,
    Accept : "application/json",
    contentType: "application/json",
    success:function(res){
      var msg = res.message;
      //$.mobile.loading("hide");
      insertChat("me", msg, 0);

    },
    error:function(res){
      //$.mobile.loading("hide");
      alert("I'm afraid something is not working right now. Wait for a while and then give it another try.");
    }
  });
};

function callConversation(txt, id) {
  //$.mobile.loading("show");
  //var txt = "start";
  insertChat("you", txt, 0);
  var dataToPost = "{\"text\": \"" + txt + "\", \"id\": \"" + id + "\"}";

  // The URI to call when invoking the service facade for the conversation service
  var toCall = urlToCall;
  $.ajax({

    url: toCall,
    type: 'POST',
    data: dataToPost,
    Accept : "application/json",
    contentType: "application/json",
    success:function(res){
      var msg = res.message;
      //$.mobile.loading("hide");
      if (res.navigation == null) {
        insertChat("me", msg, 0);
      } else {
        switch(res.navigation) {
          case "call_rpa":
            insertChat("me", msg, 0);
            callRPA(res.context);
            break;
          default:
            insertChat("me", msg, 0);
        }
      }
    },
    error:function(res){
      //$.mobile.loading("hide");
      alert("I'm afraid something is not working right now. Wait for a while and then give it another try.");
    }
  });
};

function callRPA(ctx) {
  //$.mobile.loading("show");
  //var txt = "start";
  //insertChat("you", txt, 0);
  var dataToPost = "{\"action\": \"rpa\", \"postcode\": \"" + ctx.postcode + "\", \"consumption\": \"" + ctx.consumption + "\"}";

  var toCall = "https://66278588.eu-gb.apigw.appdomain.cloud/elektra";
  $.ajax({

    url: toCall,
    type: 'POST',
    data: dataToPost,
    Accept : "application/json",
    contentType: "application/json",
    success:function(res){
      var msg = res.message;
      insertChat("me", msg, 0);
      //alert("Nimi: " + res.name + " Kuvaus: " + res.description);
      continueConversation(id);
    },
    error:function(res){
      //$.mobile.loading("hide");
      alert("Sorry, something went wrong with the call to IBM RPA.");
    }
  });
};


//-- No use time. It is a javaScript effect.
function insertChat(who, text, time = 0){
    var control = "";
    var date = formatAMPM(new Date());

    if (who == "me"){

        control = '<li style="width:100%">' +
                        '<div class="msj-black macro">' +
                        '<div class="avatar"><img style="width:80%;" src="'+ me.avatar +'" /></div>' +
                            '<div class="text text-l">' +
                                '<p>'+ text +'</p>' +
                                '<p><small>'+date+'</small></p>' +
                            '</div>' +
                        '</div>' +
                    '</li>';
    }else{
        control = '<li style="width:100%;">' +
                        '<div class="msj-rta macro">' +
                            '<div class="text text-r">' +
                                '<p>'+text+'</p>' +
                                '<p><small>'+date+'</small></p>' +
                            '</div>' +
                        '<div class="avatar" style="padding:0px 0px 0px 10px !important"><img class="img-circle" style="width:80%;" src="'+you.avatar+'" /></div>' +
                  '</li>';
    }
    setTimeout(
        function(){
            $("ul").append(control);

        }, time);

};


function resetChat(){
    $("ul").empty();
};

function say(text){
    callConversation(text, id);
};
